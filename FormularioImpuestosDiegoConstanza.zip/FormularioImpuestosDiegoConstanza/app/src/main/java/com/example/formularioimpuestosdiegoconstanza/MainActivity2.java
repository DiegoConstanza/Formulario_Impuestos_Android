package com.example.formularioimpuestosdiegoconstanza;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    TextView MNombres;
    TextView MApellidos;
    TextView MSueldo;
    TextView MIrtra;
    TextView MIgss;
    TextView MIntecap;
    TextView MIsr;
    TextView MTSueldo;
    Button Regresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        MNombres = findViewById(R.id.MNombres);
        MApellidos = findViewById(R.id.MApellidos);
        MSueldo = findViewById(R.id.MSueldo);
        MIgss = findViewById(R.id.MIgss);
        MIrtra = findViewById(R.id.MIrtra);
        MIntecap = findViewById(R.id.MIntecap);
        MIsr = findViewById(R.id.MIsr);
        MTSueldo = findViewById(R.id.MTSueldo);
        Regresar = findViewById(R.id.Regresar);

        Bundle Datos = getIntent().getExtras();
        String BNombres = Datos.getString("Nombres");
        Bundle Datos2 = getIntent().getExtras();
        String BApellidos = Datos2.getString("Apellidos");
        Bundle Datos3 = getIntent().getExtras();
        String BSueldo = Datos3.getString("Sueldo");

        double CSueldo = Double.parseDouble(BSueldo);
        double RIgss = (CSueldo * 4.83) / 100;
        double RIrtra = (CSueldo * 1) / 100;
        double RIntecap = (CSueldo * 1) / 100;
        double RIsr;
        double Restante;

        if (CSueldo > 5000 ){
            RIsr=(CSueldo*5) / 100;
        }
        else {
            RIsr = 0;
        }
        Restante = ( CSueldo - RIgss - RIrtra - RIntecap - RIsr);



        MNombres.setText("Mucho gusto: " + BNombres);
        MApellidos.setText("Se apellida: " + BApellidos);
        MSueldo.setText("Su sueldo antes de los impuestos es de: Q. " + CSueldo);
        MIrtra.setText("Debe pagar Q. " + RIrtra + " por el Irtra");
        MIgss.setText("Debe pagar Q. " + RIgss + " por el Igss");
        MIntecap.setText("Debe pagar Q. " + RIntecap + " por el Intecap");

        if (CSueldo > 5000 ){
            MIsr.setText("Debe pagar Q. " + RIsr + " por el Isr");
        }
        else {
            MIsr.setText("No debe pagar por el Isr");
        }

        MTSueldo.setText("El restante de su sueldo es de: Q. " + Restante);
    }

    public void Regresar (View view){
        Intent i= new Intent(this,MainActivity.class);
        startActivity(i);

    }

}