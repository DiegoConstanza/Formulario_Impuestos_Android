package com.example.formularioimpuestosdiegoconstanza;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    TextView MNombres;
    TextView MApellidos;
    TextView MSueldo;
    TextView MIrtra;
    TextView MIgss;
    TextView MIntecap;
    TextView MIsr;
    TextView MTSueldo;
    Button Regresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        MNombres = findViewById(R.id.MNombres);
        MApellidos = findViewById(R.id.MApellidos);
        MSueldo = findViewById(R.id.MSueldo);
        MIgss = findViewById(R.id.MIgss);
        MIrtra = findViewById(R.id.MIrtra);
        MIntecap = findViewById(R.id.MIntecap);
        MIsr = findViewById(R.id.MIsr);
        MTSueldo = findViewById(R.id.MTSueldo);
        Regresar = findViewById(R.id.Regresar);

        Bundle Datos = getIntent().getExtras();
        String BNombres = Datos.getString("Nombres");
        Bundle Datos2 = getIntent().getExtras();
        String BApellidos = Datos2.getString("Apellidos");
        Bundle Datos3 = getIntent().getExtras();
        String BSueldo = Datos3.getString("Sueldo");

        double CSueldo = Double.parseDouble(BSueldo);



        MNombres.setText("Mucho gusto: " + BNombres);
        MApellidos.setText("Se apellida: " + BApellidos);
        MSueldo.setText("Su sueldo antes de los impuestos es de: Q. " + CSueldo);
        MIrtra.setText("Debe pagar Q. " + CSueldo + " por el Irtra");
        MIgss.setText("Debe pagar Q. " + CSueldo + " por el Igss");
        MIntecap.setText("Debe pagar Q. " + CSueldo + " por el Intecap");
        MIsr.setText("Debe pagar Q. " + CSueldo + " por el Isr");
        MTSueldo.setText("El restante de su sueldo es de: Q. " + CSueldo);
    }

    public void Regresar (View view){
        Intent i= new Intent(this,MainActivity.class);
        startActivity(i);

    }

}